<?php
session_start();
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']!=''){
$_SESSION['login']='';
}
if(isset($_POST['login']))
{

$email=$_POST['emailid'];
$password=md5($_POST['password']);
$sql ="SELECT EmailId,Password,StudentId,Status FROM tblstudents WHERE EmailId=:email and Password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0)
{
 foreach ($results as $result) {
 $_SESSION['stdid']=$result->StudentId;
if($result->Status==1)
{
$_SESSION['login']=$_POST['emailid'];
echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
} else {
echo "<script>alert('Your Account Has been blocked .Please contact admin');</script>";

}
}

} 

else{
echo "<script>alert('Invalid Details');</script>";
}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GPA Library | Home</title>
    
    <link rel="stylesheet" href="index.css" />
</head>
<body>
    <div class="top-bar">
        <p>Monday - Friday, 10AM to 5PM | Call us now +91 - 0000000000</p>
    </div>
    <div class="name-bar">
        <a href="index.php" class="logo"><img src="images/logo1.png" alt="Logo"> GPA Knowledge Hub - "Where Curiosity Meets Wisdom!"</a>
    </div>
    <nav>
        <ul>
            <li><a href="index.php" class="active">Home</a></li>
            <li><a href="about.php">About</a></li>
        </ul>
        <div class="login-buttons">
            <a href="login.php">Sign in as User</a>
           <!-- <a href="signup.php">Sign in as Faculty</a>-->
        </div>
    </nav>

    <div class="hero-section">
        <div class="hero-overlay">
            <h2>Library Management System</h2>
            <p>"Freedom to read, hear, view, think @ your library."</p>
        </div>
    </div>

    <section class="features-section">
        <div class="features-container">
            <div class="feature">
                <h3>Easy Book Search</h3>
                <p>Find books by name, author, or ISBN with a few clicks.</p>
            </div>
            <div class="feature">
                <h3>Borrow Books</h3>
                <p>Borrow your favorite books for a specified time.</p>
            </div>
            <div class="feature">
                <h3>Student Login</h3>
                <p>Students can log in to view their borrowing history.</p>
            </div>
        </div>
    </section>

    <section class="faq-section">
        <h2>Frequently Asked Questions</h2>
        <div>
            <button class="accordion">What is the borrowing limit?</button>
            <div class="accordion-content">
                <p>Students can borrow up to 3 books at a time.</p>
            </div>
            <button class="accordion">What happens if I lose a book?</button>
            <div class="accordion-content">
                <p>You will be required to replace it or pay a fine.</p>
            </div>
        </div>
    </section>

    <footer>
        &copy; <?php echo date('Y'); ?> GPA Library. All rights reserved by Government Polytechnic, Awasari (Kh).
    </footer>

    <script>
        const accordions = document.querySelectorAll('.accordion');
        accordions.forEach((accordion) => {
            accordion.addEventListener('click', () => {
                accordion.classList.toggle('active');
                const content = accordion.nextElementSibling;
                content.style.display = content.style.display === 'block' ? 'none' : 'block';
            });
        });
    </script>
</body>
</html>
