<?php
session_start();
error_reporting(0);
include('includes/config.php');

if (strlen($_SESSION['login']) == 0) {   
    header('location:index.php');
} else {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>GPA Library | Issued Books</title>
    <!-- BOOTSTRAP CORE STYLE -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!-- FONT AWESOME STYLE -->
    <link href="assets/css/font-awesome.css" rel="stylesheet">
    <!-- CUSTOM STYLE -->
    <link href="assets/css/style.css" rel="stylesheet">
    <!-- GOOGLE FONT -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
</head>
<body>
    <!-- MENU SECTION START -->
    <?php include('includes/header.php'); ?>
    <!-- MENU SECTION END -->

    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">Manage Issued Books</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Issued Books</div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Book Name</th>
                                            <th>ISBN</th>
                                            <th>Issue Date</th>
                                            <th>Due Date</th>
                                            <th>Return Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        if (!isset($_SESSION['stdid'])) {
                                            echo '<tr><td colspan="6" class="text-center">Session Expired. Please login again.</td></tr>';
                                        } else {
                                            $sid = $_SESSION['stdid'];

                                            // Pagination setup
                                            $limit = 10; // Number of records per page
                                            $page = isset($_GET['page']) ? $_GET['page'] : 1;
                                            $start = ($page - 1) * $limit;

                                            // Fetch total number of records
                                            $sql_count = "SELECT COUNT(*) FROM issue WHERE studentID = :sid";
                                            $query_count = $dbh->prepare($sql_count);
                                            $query_count->bindParam(':sid', $sid, PDO::PARAM_STR);
                                            $query_count->execute();
                                            $total_records = $query_count->fetchColumn();
                                            $total_pages = ceil($total_records / $limit);

                                            // Fetch issued books with pagination
                                            $sql = "SELECT 
                                                        i.issueID,  
                                                        b.name AS BookName, 
                                                        b.ISBN_NO, 
                                                        i.issueDate, 
                                                        i.dueDate, 
                                                        i.returnBook 
                                                    FROM issue i
                                                    JOIN student s ON s.studentID = i.studentID
                                                    JOIN book b ON b.bookID = i.bookID
                                                    WHERE s.studentID = :sid 
                                                    ORDER BY i.issueID DESC 
                                                    LIMIT :start, :limit";

                                            $query = $dbh->prepare($sql);
                                            $query->bindParam(':sid', $sid, PDO::PARAM_STR);
                                            $query->bindParam(':start', $start, PDO::PARAM_INT);
                                            $query->bindParam(':limit', $limit, PDO::PARAM_INT);
                                            $query->execute();
                                            $results = $query->fetchAll(PDO::FETCH_OBJ);
                                            $cnt = $start + 1;

                                            if ($query->rowCount() > 0) {
                                                foreach ($results as $result) { ?>                                      
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($cnt); ?></td>
                                                        <td><?php echo htmlspecialchars($result->BookName); ?></td>
                                                        <td><?php echo htmlspecialchars($result->ISBN_NO); ?></td>
                                                        <td><?php echo htmlspecialchars($result->issueDate); ?></td>
                                                        <td><?php echo htmlspecialchars($result->dueDate); ?></td>
                                                        <td>
                                                            <?php if ($result->returnBook == "No") { ?>
                                                                <span style="color:red">Not Returned</span>
                                                            <?php } else { ?>
                                                                <span style="color:green">Returned</span>
                                                            <?php } ?>
                                                        </td>
                                                    </tr>
                                            <?php 
                                                    $cnt++;
                                                }
                                            } else { ?>
                                                <tr>
                                                    <td colspan="6" class="text-center">No books issued</td>
                                                </tr>
                                            <?php } 
                                        } ?>                                       
                                    </tbody>
                                </table>

                                <!-- Pagination Links -->
                                <nav>
                                    <ul class="pagination">
                                        <?php for ($i = 1; $i <= $total_pages; $i++) { ?>
                                            <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                                                <a class="page-link" href="?page=<?php echo $i; ?>">
                                                    <?php echo $i; ?>
                                                </a>
                                            </li>
                                        <?php } ?>
                                    </ul>
                                </nav>

                            </div>
                        </div>
                    </div>
                    <!-- End Table -->
                </div>
            </div>
        </div>
    </div>

    <!-- FOOTER SECTION -->
    <?php include('includes/footer.php'); ?>

</body>
</html>
<?php } ?>
