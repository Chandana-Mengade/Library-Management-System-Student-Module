<?php
// Start session if it's not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include('includes/config.php'); // Include database connection

// Check if the session has login data
if (isset($_SESSION['login'])) {
    $studentID = $_SESSION['login'];

    // Get the current date
    $currentDate = date('Y-m-d');
    
    // Query to fetch overdue and due soon books for the logged-in student
    $sql = "SELECT issue.issueID, issue.bookID, issue.bookName, issue.studentID, issue.dueDate, student.email, student.name
            FROM issue 
            JOIN student ON issue.studentID = student.studentID
            WHERE issue.studentID = :studentID
            AND (issue.dueDate < :currentDate AND issue.returnBook = 'No') OR
                (DATEDIFF(issue.dueDate, :currentDate) <= 3 AND issue.returnBook = 'No')
            ORDER BY issue.dueDate ASC";

    $query = $dbh->prepare($sql);
    $query->bindParam(':studentID', $studentID, PDO::PARAM_STR);
    $query->bindParam(':currentDate', $currentDate, PDO::PARAM_STR);
    $query->execute();
    $notifications = $query->fetchAll(PDO::FETCH_OBJ);

    // If the session has 'ignored_books', use it, else initialize it as an empty array
    $ignoredBooks = isset($_SESSION['ignored_books']) ? $_SESSION['ignored_books'] : [];

    // Loop through the notifications and handle actions
    foreach ($notifications as $notif) {
        $bookName = $notif->bookName;
        $dueDate = $notif->dueDate;
        $studentEmail = $notif->email;
        $studentName = $notif->name;  // Get the student's name for personalization

        // Check if the book is ignored
        if (!in_array($bookName, $ignoredBooks)) {
            // Send email if the book is overdue or due soon
            if ($dueDate < $currentDate) {
                $subject = "Overdue Book Notification";
                $message = "Dear $studentName,\n\nYour book '$bookName' is overdue. The due date was $dueDate. Please return it as soon as possible.\n\nBest regards,\nLibrary Team";
            } else {
                $subject = "Due Soon Book Notification";
                $message = "Dear $studentName,\n\nYour book '$bookName' is due soon. The due date is $dueDate. Please return it before the due date.\n\nBest regards,\nLibrary Team";
            }

            // Send the email
            $headers = "From: library@example.com\r\n";
            $headers .= "Reply-To: library@example.com\r\n";
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

            // Send the email using PHP mail function
            if (mail($studentEmail, $subject, $message, $headers)) {
                echo "Notification sent to $studentName ($studentEmail) for the book '$bookName'.\n";
            } else {
                echo "Failed to send notification to $studentName ($studentEmail) for the book '$bookName'.\n";
            }

            // Add the book to the ignored list (mark it as read)
            if (!isset($_SESSION['ignored_books'])) {
                $_SESSION['ignored_books'] = [];
            }
            $_SESSION['ignored_books'][] = $bookName;
        }
    }

    // Handle actions based on POST data
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        // Handle 'markRead' action
        if ($action == 'markRead' && isset($_POST['bookName'])) {
            $bookName = $_POST['bookName'];

            // Add the book to the ignored list (mark it as read)
            if (!in_array($bookName, $_SESSION['ignored_books'])) {
                $_SESSION['ignored_books'][] = $bookName;
            }
        }

        // Handle 'clearAll' action
        if ($action == 'clearAll') {
            // Clear the ignored books array (all notifications cleared)
            $_SESSION['ignored_books'] = [];
        }
    }
}
?>

<!-- Navbar -->
<div class="navbar navbar-inverse set-radius-zero">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <div class="name-bar">
                <a href="index.php" class="logo">
                    <img src="images/logo1.png" alt="Logo"> 
                    GPA Knowledge Hub - "Where Curiosity Meets Wisdom!"
                </a>
            </div>
        </div>

        <?php if (isset($_SESSION['login'])) { ?> 
            <div class="right-div">
                <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
            </div>
        <?php } ?>
    </div>
</div>

<?php if ($_SESSION['login']) { ?>    
<section class="menu-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar-collapse collapse">
                    <ul id="menu-top" class="nav navbar-nav navbar-right">
                        <li><a href="dashboard.php" class="menu-top-active">DASHBOARD</a></li>
                        <li><a href="issued-books.php">Issued Books</a></li>

                        <!-- Notifications Menu -->
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-bell" style="font-size: 24px; color: #FBBF24;"></i>
                                <?php if (count($notifications) > 0) { ?>
                                    <span class="badge badge-danger" id="notifCount" 
                                        style="position: absolute; top: 5px; right: 5px; background: red; font-size: 12px;">
                                        <?php echo count($notifications); ?>
                                    </span>
                                <?php } ?>
                            </a>
                            <ul class="dropdown-menu notif-dropdown">
                                <?php if (count($notifications) > 0) { ?>
                                    <li class="text-center">
                                        <form action="handle_notifications.php" method="post">
                                            <input type="hidden" name="action" value="clearAll">
                                            <button type="submit" class="btn btn-link">Clear All</button>
                                        </form>
                                    </li>
                                    <li class="divider"></li>
                                    <?php foreach ($notifications as $notif) {
                                        $message = ($notif->dueDate < $currentDate) ? "Overdue: " : "Due Soon: ";
                                    ?>
                                        <li>
                                            <form action="handle_notifications.php" method="post">
                                                <input type="hidden" name="action" value="markRead">
                                                <input type="hidden" name="bookName" value="<?php echo $notif->bookName; ?>">
                                                <button type="submit" class="btn btn-link"><?php echo $message . $notif->bookName . " (Due: " . $notif->dueDate . ")"; ?></button>
                                            </form>
                                        </li>
                                    <?php } ?>
                                <?php } else { ?>
                                    <li class="text-center"><a href="#">No notifications</a></li>
                                <?php } ?>
                            </ul>
                        </li>

                        <li>
                            <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Account <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="ddlmenuItem">
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="my-profile.php">My Profile</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<?php } else { ?>
<section class="menu-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar-collapse collapse">
                    <ul id="menu-top" class="nav navbar-nav navbar-right">                        
                        <li><a href="index.php">Home</a></li>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="signup.php"> Signup</a></li>
                        <li><a href="about.php">About Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php } ?>  
