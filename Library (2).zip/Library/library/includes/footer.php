   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                GPA Library . All rights reserved by Government Polytechnic, Awasari (Kh).</a> 
                </div>

            </div>
        </div>
    </section>