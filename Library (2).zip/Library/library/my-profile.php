<?php 
session_start();
require_once 'includes/config.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if(strlen($_SESSION['login']) == 0) {   
    header('location:index.php');
} else { 
    if(isset($_POST['update'])) {    
        $sid = $_SESSION['stdid'];  
        $fname = $_POST['fullname']; 
        $phone = $_POST['phoneNumber']; // Correct column name
        $branch = $_POST['branch'];
        $year = $_POST['year'];

        $sql = "UPDATE student SET name=:fname, phoneNumber=:phone, branchName=:branch, year=:year WHERE studentID=:sid";
        $query = $dbh->prepare($sql);
        $query->bindParam(':sid', $sid, PDO::PARAM_STR);
        $query->bindParam(':fname', $fname, PDO::PARAM_STR);
        $query->bindParam(':phone', $phone, PDO::PARAM_STR);
        $query->bindParam(':branch', $branch, PDO::PARAM_STR);
        $query->bindParam(':year', $year, PDO::PARAM_STR);

        if ($query->execute()) {
            echo '<script>alert("Your profile has been updated")</script>';
        } else {
            echo '<script>alert("Error updating profile")</script>';
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Library | My Profile</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>

<?php include('includes/header.php'); ?>

<div class="content-wrapper">
    <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">My Profile</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9 col-md-offset-1">
                <div class="panel panel-info">
                    <div class="panel-heading">My Profile</div>
                    <div class="panel-body">
                        <form name="updateProfile" method="post">
                            <?php 
                            $sid = $_SESSION['stdid'];
                            $sql = "SELECT studentID, name, email, phoneNumber, branchName, year FROM student WHERE studentID=:sid";
                            $query = $dbh->prepare($sql);
                            $query->bindParam(':sid', $sid, PDO::PARAM_STR);
                            $query->execute();
                            $result = $query->fetch(PDO::FETCH_OBJ);

                            if ($result) { ?>  
                                <div class="form-group">
                                    <label>Student ID:</label>
                                    <?php echo htmlentities($result->studentID); ?>
                                </div>

                                <div class="form-group">
                                    <label>Enter Full Name</label>
                                    <input class="form-control" type="text" name="fullname" value="<?php echo htmlentities($result->name); ?>" required />
                                </div>

                                <div class="form-group">
                                    <label>Mobile Number:</label>
                                    <input class="form-control" type="text" name="phoneNumber" maxlength="15" value="<?php echo htmlentities($result->phoneNumber); ?>" required />
                                </div>

                                <div class="form-group">
                                    <label>Branch:</label>
                                    <input class="form-control" type="text" name="branch" value="<?php echo htmlentities($result->branchName); ?>" required />
                                </div>

                                <div class="form-group">
                                    <label>Year:</label>
                                    <input class="form-control" type="text" name="year" value="<?php echo htmlentities($result->year); ?>" required />
                                </div>
                                
                                <div class="form-group">
                                    <label>Email</label>
                                    <input class="form-control" type="email" name="email" value="<?php echo htmlentities($result->email); ?>" readonly />
                                </div>

                                <button type="submit" name="update" class="btn btn-primary">Update Now</button>
                            <?php } else { ?>
                                <p class="text-danger">Error: Student profile not found.</p>
                            <?php } ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>

<script src="assets/js/jquery-1.10.2.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/custom.js"></script>

</body>
</html>
<?php } ?>
