<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0) {   
    header('location:index.php');
} else { 
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>GPA Library | Library Books</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>
<body>
<?php include('includes/header.php'); ?>

<div class="content-wrapper">
    <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Library Books</h4>
            </div>
        </div>
        
        <!-- Search Form -->
        <form method="GET" action="">
            <div class="form-group">
                <input type="text" name="search" class="form-control" placeholder="Search by Book Name, Author, or Category" value="<?php echo isset($_GET['search']) ? htmlentities($_GET['search']) : ''; ?>">
            </div>
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
        <br>
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Books</div>
                    <div class="panel-body">
                    <?php 
                    $searchQuery = "WHERE 1=1"; 
                    if(isset($_GET['search']) && !empty($_GET['search'])) {
                        $searchText = "%" . $_GET['search'] . "%";
                        $searchQuery .= " AND (book.name LIKE :search OR book.author LIKE :search OR book.category LIKE :search)";
                    }

                    // Updated SQL Query to correctly fetch available books
                    $sql = "SELECT 
                                book.bookID, 
                                book.accessionNo, 
                                book.ISBN_NO, 
                                book.name, 
                                book.category, 
                                book.author, 
                                book.publisherYear, 
                                book.quantity, 
                                (book.quantity - COALESCE((SELECT COUNT(*) FROM issue WHERE issue.bookID = book.bookID AND issue.returnBook = 'No'), 0)) AS availableQuantity 
                            FROM book
                            $searchQuery";

                    $query = $dbh->prepare($sql);
                    if (!empty($_GET['search'])) {
                        $query->bindParam(':search', $searchText, PDO::PARAM_STR);
                    }
                    $query->execute();
                    $results = $query->fetchAll(PDO::FETCH_OBJ);
                    
                    if($query->rowCount() > 0) {
                        foreach($results as $result) { ?>  
                            <div class="col-md-4" style="height:370px;">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Book Name</th>
                                        <td><?php echo htmlentities($result->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Accession No</th>
                                        <td><?php echo htmlentities($result->accessionNo); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Author</th>
                                        <td><?php echo htmlentities($result->author); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Category</th>
                                        <td><?php echo htmlentities($result->category); ?></td>
                                    </tr>
                                    <tr>
                                        <th>ISBN Number</th>
                                        <td><?php echo htmlentities($result->ISBN_NO); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Publisher Year</th>
                                        <td><?php echo htmlentities($result->publisherYear); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Total Quantity</th>
                                        <td><?php echo htmlentities($result->quantity); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Available Quantity</th>
                                        <td><?php echo htmlentities($result->availableQuantity); ?></td>
                                    </tr>
                                </table>
                            </div>
                    <?php } } else { echo "<p>No books found.</p>"; } ?>  
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>
<script src="assets/js/jquery-1.10.2.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/dataTables/jquery.dataTables.js"></script>
<script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
<script src="assets/js/custom.js"></script>
</body>
</html>
<?php } ?>
