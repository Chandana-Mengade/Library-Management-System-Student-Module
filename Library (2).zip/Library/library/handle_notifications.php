<?php
session_start();
include('includes/config.php');

// Check if the session has login data
if (isset($_SESSION['login'])) {
    $studentID = $_SESSION['login'];

    // Handle actions based on POST data
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        // Handle 'markRead' action
        if ($action == 'markRead' && isset($_POST['bookName'])) {
            $bookName = $_POST['bookName'];

            // Add the book to the ignored list (mark it as read)
            if (!isset($_SESSION['ignored_books'])) {
                $_SESSION['ignored_books'] = [];
            }
            if (!in_array($bookName, $_SESSION['ignored_books'])) {
                $_SESSION['ignored_books'][] = $bookName;
            }
        }

        // Handle 'clearAll' action
        if ($action == 'clearAll') {
            // Clear the ignored books array (all notifications cleared)
            $_SESSION['ignored_books'] = [];
        }
    }

    // Redirect to the notifications page (or any other page you want)
    header("Location: issued-books.php");
    exit();
} else {
    // Redirect to login page if the user is not logged in
    header("Location: login.php");
    exit();
}
?>
