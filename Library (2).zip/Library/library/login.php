<?php
session_start();
include('includes/config.php'); // Database connection
error_reporting(0);

if(isset($_POST['login'])) {
    $email = $_POST['emailid'];
    $studentID = $_POST['password']; // Password is studentID

    $sql = "SELECT studentID FROM student WHERE email=:email AND studentID=:studentID";
    $query = $dbh->prepare($sql);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':studentID', $studentID, PDO::PARAM_STR);
    $query->execute();
    $result = $query->fetch(PDO::FETCH_OBJ);

    if($result) {
        $_SESSION['stdid'] = $result->studentID;  
        $_SESSION['login'] = $email;
        echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
    } else {
        echo "<script>alert('Invalid Email or Student ID!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GPA Library | Login</title>
    
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>

<!-- Header with Logo -->
<div class="name-bar">
    <a href="index.php" class="logo">
        <img src="images/logo1.png" alt="Logo"> GPA Knowledge Hub - "Where Curiosity Meets Wisdom!"
    </a>
</div>
<!-- Navigation Bar -->
<nav>
    <ul>
        <li><a href="index.php" class="active">Home</a></li>
        <li><a href="about.php">About</a></li>
    </ul>
    <div class="login-buttons">
        <a href="login.php">Sign in</a>
    </div>
</nav>

<!-- Login Form -->
<div class="content-wrapper">
    <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Student Login</h4>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-info">
                    <div class="panel-heading"> LOGIN FORM </div>
                    <div class="panel-body">
                        <form method="post">
                            <div class="form-group">
                                <label>Email</label>
                                <input class="form-control" type="email" name="emailid" required />
                            </div>

                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" type="password" name="password" required />
                            </div>

                            <button type="submit" name="login" class="btn btn-info">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap Scripts -->
<script src="assets/js/jquery-1.10.2.js"></script>
<script src="assets/js/bootstrap.js"></script>

</body>
</html>
