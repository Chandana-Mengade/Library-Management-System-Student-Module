<?php
session_start();
error_reporting(0);
include('includes/config.php');

if(strlen($_SESSION['login'])==0) { 
    header('location:index.php');
} else { 
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>GPA Library | User Dashboard</title>
    
    <!-- BOOTSTRAP CORE STYLE -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>

<?php include('includes/header.php'); ?>

<div class="content-wrapper">
    <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">User DASHBOARD</h4>
            </div>
        </div>

        <div class="row">

            <!-- Total Books Listed -->
            <a href="listed-books.php">
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="alert alert-success back-widget-set text-center">
                        <i class="fa fa-book fa-5x"></i>
                        <?php 
                        $sql = "SELECT COUNT(bookID) AS totalBooks FROM book"; 
                        $query = $dbh->prepare($sql);
                        $query->execute();
                        $result = $query->fetch(PDO::FETCH_ASSOC);
                        ?>
                        <h3><?php echo htmlentities($result['totalBooks']); ?></h3>
                        Books Listed
                    </div>
                </div>
            </a>

            <!-- Books Not Returned -->
            <div class="col-md-4 col-sm-4 col-xs-6">
                <div class="alert alert-warning back-widget-set text-center">
                    <i class="fa fa-recycle fa-5x"></i>
                    <?php 
                    $sid = $_SESSION['stdid'];
                    $sql2 = "SELECT COUNT(issueID) AS notReturned FROM issue WHERE studentID=:sid AND returnBook='No'";
                    $query2 = $dbh->prepare($sql2);
                    $query2->bindParam(':sid', $sid, PDO::PARAM_STR);
                    $query2->execute();
                    $result2 = $query2->fetch(PDO::FETCH_ASSOC);
                    ?>
                    <h3><?php echo htmlentities($result2['notReturned']); ?></h3>
                    Books Not Returned Yet
                </div>
            </div>

            <!-- Total Issued Books -->
            <a href="issued-books.php">
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="alert alert-success back-widget-set text-center">
                        <i class="fa fa-book fa-5x"></i>
                        <?php 
                        $sql3 = "SELECT COUNT(issueID) AS totalIssued FROM issue WHERE studentID=:sid";
                        $query3 = $dbh->prepare($sql3);
                        $query3->bindParam(':sid', $sid, PDO::PARAM_STR);
                        $query3->execute();
                        $result3 = $query3->fetch(PDO::FETCH_ASSOC);
                        ?>
                        <h3><?php echo htmlentities($result3['totalIssued']); ?></h3>
                        Total Issued Books
                    </div>
                </div>
            </a>

        </div>    
    </div>
</div>

<?php include('includes/footer.php'); ?>

<!-- JAVASCRIPT FILES -->
<script src="assets/js/jquery-1.10.2.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/custom.js"></script>

</body>
</html>
<?php } ?>  
