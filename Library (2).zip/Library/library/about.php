<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="about.css"> <!-- Link to external CSS -->
</head>
<body>
<div class="name-bar">
     	<a href="index.php" class="logo"><img src="images/logo1.png" alt="Logo"> Government Polytechnic, Awasari (Kh.) Library</a>
    </div>
    <header>
        <nav class="navbar">
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php" class="active">About Us</a></li>
                
            </ul>
        </nav>
    </header>
    
    <main>
        <div class="about-container">
            <!-- <img src="assets/images/about-us-banner.jpg" alt="About Us Banner" class="about-banner">-->
            <h1 class="about-title">About Us</h1>
            <p class="about-text">
                Welcome to our Library Management System! Our platform is designed to make borrowing and managing library resources as seamless as possible.
            </p>
            <p class="about-text">
                Our mission is to foster a love for reading and learning by providing <span class="highlight">easy access</span> to a wide collection of books and resources for students and staff. 
                We aim to simplify the library experience with an intuitive <span class="highlight">user interface</span> and robust features.
            </p>
            <p class="about-text">
                Key highlights of our system include:
                <ul>
                    <li>Quick book searches by name, author, or ISBN.</li>
                    <li>Simple borrowing and reservation processes.</li>
                    <li>Timely notifications for due dates and overdue fines.</li>
                </ul>
            </p>
            <p class="about-text">
                Our dedicated team is constantly working to improve the platform to meet the needs of our users. 
                If you have any feedback or questions, please don't hesitate to <a href="contact.jsp">contact us</a>.
            </p>
            <p class="about-text last-updated">
    Last Updated on: <?php echo date("F d, Y, h:i A"); ?>
</p>

        </div>
    </main>
    
    <footer class="footer">
    &copy; <?php echo date("Y"); ?> GPA Library. All rights reserved by Government Polytechnic, Awasari (Kh).
</footer>

</body>
</html>